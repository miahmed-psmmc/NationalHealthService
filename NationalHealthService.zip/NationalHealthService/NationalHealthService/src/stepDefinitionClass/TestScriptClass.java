package stepDefinitionClass;

import java.io.File;
//import java.io.FileNotFoundException;
import java.io.PrintStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.ie.InternetExplorerDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

	public class TestScriptClass {	
	private static WebDriver driver = null;
	@Given("^I am a person from Wales$")
	public void I_am_a_person_from_Wales() throws Throwable {
//		SWITCH TO FRIEFOX BROWSER 
//		WebDriver driver = new FirefoxDriver();
// 		SWITCH TO INTERNET EXPLORER
//		System.setProperty("webdriver.ie.driver", "D:\\NationalHealthService\\NationalHealthService\\Jars\\IEDriverServer.exe");
//		WebDriver driver = new InternetExplorerDriver();
// 		SWITCH TO GOOGLE CHROME
		System.setProperty("webdriver.chrome.driver", "D:\\NationalHealthService\\NationalHealthService\\Jars\\chromedriver.exe");
		driver = new ChromeDriver();
// 		LAUNCHING WEBSITE
		driver.get("https://services.nhsbsa.nhs.uk/check-for-help-paying-nhs-costs/start/");
		driver.manage().window().maximize();
/*		WebDriverWait wait = new WebDriverWait(driver, 20);
		WebElement _clickStart;
	    _clickStart = driver.findElement(By.id("next-button"));
	    WebElement WE = wait.until(ExpectedConditions.elementToBeClickable(_clickStart));
	    WE.submit();
*/
		WebElement _clickStart;
	    _clickStart = driver.findElement(By.id("next-button"));
	    _clickStart.submit();
		WebElement _selectCountry;
		_selectCountry = driver.findElement(By.id("label-wales"));
		//_selectCountry = driver.findElement(By.xpath("//input[@id='radio-wales' and @type='radio' @name='livingCountry' and @value='WALES']"));
		WebElement _selectCountryStatus;
		_selectCountryStatus = driver.findElement(By.id("radio-wales"));
		boolean _radioBtnCountryWalesEnable = _selectCountryStatus.isEnabled();
		
		PrintStream o = new PrintStream(new File("D:\\NationalHealthService\\NationalHealthService\\Logs\\Logs.txt"));
//		PrintStream console = System.out;
		System.setOut(o);
		
		System.out.println("Is county Wales radio button enabled?: "+_radioBtnCountryWalesEnable);
		_selectCountry.click();
		boolean _radioBtnCountryWalesSelect = _selectCountryStatus.isSelected();
        System.out.println("Is county Wales selected?: "+_radioBtnCountryWalesSelect);
		WebElement _clickNextCountry;
		_clickNextCountry = driver.findElement(By.id("next-button"));
		_clickNextCountry.submit();
	}
	
	@When("^I put my circumstances into the Checker tool$")
	public void I_put_my_circumstances_into_the_Checker_tool() throws Throwable {
		WebElement _dateOfBirth_Day;
		_dateOfBirth_Day = driver.findElement(By.name("dateOfBirth.day"));
		_dateOfBirth_Day.sendKeys("28");
		WebElement _dateOfBirth_Month;
		_dateOfBirth_Month = driver.findElement(By.name("dateOfBirth.month"));
		_dateOfBirth_Month.sendKeys("07");
		WebElement _dateOfBirth_Year;
		_dateOfBirth_Year = driver.findElement(By.name("dateOfBirth.year"));
		_dateOfBirth_Year.sendKeys("1981");
		WebElement _clickNextDoB;
		_clickNextDoB = driver.findElement(By.id("next-button"));
		_clickNextDoB.submit();

		WebElement _liveWithPartner;
		_liveWithPartner = driver.findElement(By.id("label-yes"));
		WebElement _liveWithPartnerStatus;
		_liveWithPartnerStatus = driver.findElement(By.id("radio-yes"));
		_liveWithPartner.click();
		boolean _liveWithPartnerSelect = _liveWithPartnerStatus.isSelected();
		System.out.println("Is live with a partner (YES) selected?: "+_liveWithPartnerSelect);
		WebElement _clickNextliveWithPartner;
		_clickNextliveWithPartner = driver.findElement(By.id("next-button"));
		_clickNextliveWithPartner.submit();
		
		WebElement _claimBenefits;
		_claimBenefits = driver.findElement(By.id("label-no"));
		WebElement _claimBenefitsStatus;
		_claimBenefitsStatus = driver.findElement(By.id("radio-no"));
		_claimBenefits.click();
		boolean _radioBtnClaimBenefitsSelect = _claimBenefitsStatus.isSelected();
		System.out.println("Is claim benefits or tax credits (NO) selected?: "+_radioBtnClaimBenefitsSelect);
		WebElement _clickNextClaimBenefits;
		_clickNextClaimBenefits = driver.findElement(By.id("next-button"));
		_clickNextClaimBenefits.submit();
		
		WebElement _areYouPregnant;
		_areYouPregnant = driver.findElement(By.id("label-yes"));
		WebElement _areYouPregnantStatus;
		_areYouPregnantStatus = driver.findElement(By.id("radio-yes"));
		_areYouPregnant.click();
		boolean _radioBtnAreYouPregnantSelect = _areYouPregnantStatus.isSelected();
		System.out.println("Is pregnant (YES) selected?: "+_radioBtnAreYouPregnantSelect);
		WebElement _clickNextPregnant;
		_clickNextPregnant = driver.findElement(By.id("next-button"));
		_clickNextPregnant.submit();
		
		WebElement _injuryOrIllness;
		_injuryOrIllness = driver.findElement(By.id("label-yes"));
		WebElement _injuryOrIllnessStatus;
		_injuryOrIllnessStatus = driver.findElement(By.id("radio-yes"));
		_injuryOrIllness.click();
		boolean _radioBtnInjuryOrIllnessSelect = _injuryOrIllnessStatus.isSelected();
		System.out.println("Is injury or illness (YES) selected?: "+_radioBtnInjuryOrIllnessSelect);
		WebElement _clickNextInjuryOrIllness;
		_clickNextInjuryOrIllness = driver.findElement(By.id("next-button"));
		_clickNextInjuryOrIllness.submit();
		
		WebElement _diabetes;
		_diabetes = driver.findElement(By.id("label-yes"));
		WebElement _diabetesStatus;
		_diabetesStatus = driver.findElement(By.id("radio-yes"));
		_diabetes.click();
		boolean _radioBtnDiabetesSelect = _diabetesStatus.isSelected();
		System.out.println("Is diabetes (YES) selected?: "+_radioBtnDiabetesSelect);
		WebElement _clickNextDiabetes;
		_clickNextDiabetes = driver.findElement(By.id("next-button"));
		_clickNextDiabetes.submit();
		 
		WebElement _glaucoma;
		_glaucoma = driver.findElement(By.id("label-no"));
		WebElement _glaucomaStatus;
		_glaucomaStatus = driver.findElement(By.id("radio-no"));
		_glaucoma.click();
		boolean _radioBtnGlaucomaSelect = _glaucomaStatus.isSelected();
		System.out.println("Is having glaucoma (NO) selected?: "+_radioBtnGlaucomaSelect);
		WebElement _clickNextGlaucoma;
		_clickNextGlaucoma = driver.findElement(By.id("next-button"));
		_clickNextGlaucoma.submit();
		
		WebElement _careHome;
		_careHome = driver.findElement(By.id("label-no"));
		WebElement _careHomeStatus;
		_careHomeStatus = driver.findElement(By.id("radio-no"));
		_careHome.click();
		boolean _radioBtnCareHomeSelect = _careHomeStatus.isSelected();
		System.out.println("Is living permanently in care home (NO) selected?: "+_radioBtnCareHomeSelect);
		WebElement _clickNextCareHome;
		_clickNextCareHome = driver.findElement(By.id("next-button"));
		_clickNextCareHome.submit();
		
		WebElement _savings;
		_savings = driver.findElement(By.id("label-no"));
		WebElement _savingsStatus;
		_savingsStatus = driver.findElement(By.id("radio-no"));
		_savings.click();
		boolean _radioBtnSavingsSelect = _savingsStatus.isSelected();
		System.out.println("Is savings, investments or property (NO) selected?: "+_radioBtnSavingsSelect);
		WebElement _clickNextSavings;
		_clickNextSavings = driver.findElement(By.id("next-button"));
		_clickNextSavings.submit();
	}
	
	@Then("^I should get a result of whether I will get help or not$")
	public void I_should_get_a_result_of_whether_I_will_get_help_or_not() throws Throwable {
		WebElement _result;
		_result = driver.findElement(By.id("lis-button"));
		if(_result.isDisplayed())
		{
		System.out.println("You will get help with NHS costs");
		}
		else
		System.out.println("You wouldn't get help with NHS costs");
		driver.quit();
	}
}